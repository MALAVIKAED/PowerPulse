'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  ArrowUpRight,
  CloudRain,
  LayoutDashboard,
  MessageSquare,
  Truck,
  ZapOff,
  CheckCircle2,
} from 'lucide-react'
import { PageHeader, StatTile, Card } from '@/components/app/ui'
import { LivePowerStatus } from '@/components/app/live-status'
import { AiEstimation } from '@/components/app/ai-estimation'
import { OutageTimeline } from '@/components/app/outage-timeline'
import {
  dashboardStats,
  outages,
  primaryOutage,
} from '@/lib/data'
import { outageStatusMeta, timeUntil } from '@/lib/status'
import { cn } from '@/lib/utils'

const statIcons = [ZapOff, Truck, CheckCircle2, MessageSquare]

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        icon={LayoutDashboard}
        title="Grid Command Center"
        subtitle="Live monsoon power status across the Idukki High Range"
        action={
          <span className="inline-flex items-center gap-2 rounded-full border border-border glass px-3 py-1.5 text-xs">
            <span className="relative flex size-2">
              <span className="pulse-on absolute size-2 rounded-full bg-power-on" />
              <span className="relative size-2 rounded-full bg-power-on" />
            </span>
            Live · updated just now
          </span>
        }
      />

      {/* Stat tiles */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {dashboardStats.map((s, i) => (
          <StatTile key={s.label} stat={s} icon={statIcons[i]} index={i} />
        ))}
      </div>

      {/* Main grid */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <LivePowerStatus outage={primaryOutage} />
          <AiEstimation outage={primaryOutage} />
          <AffectedAreas />
        </div>
        <div className="space-y-4">
          <OutageTimeline />
          <RainfallCard />
        </div>
      </div>
    </>
  )
}

function AffectedAreas() {
  const active = outages.filter((o) => o.status !== 'restored')
  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-display text-sm font-semibold">Affected Areas</h3>
          <p className="text-xs text-muted-foreground">
            {active.length} active outages right now
          </p>
        </div>
        <Link
          href="/map"
          className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
        >
          View map <ArrowUpRight className="size-3.5" />
        </Link>
      </div>
      <div className="space-y-2">
        {outages.slice(0, 5).map((o, i) => {
          const meta = outageStatusMeta[o.status]
          return (
            <motion.div
              key={o.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3 rounded-xl border border-border bg-background/40 p-3"
            >
              <span className={cn('size-2.5 shrink-0 rounded-full', meta.dot)} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{o.area}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {o.cause}
                </p>
              </div>
              <div className="text-right">
                <p className={cn('text-xs font-semibold', meta.text)}>
                  {meta.label}
                </p>
                <p className="text-xs text-muted-foreground">
                  {o.status === 'restored'
                    ? 'Restored'
                    : `~${timeUntil(o.estimatedRestoration)}`}
                </p>
              </div>
            </motion.div>
          )
        })}
      </div>
    </Card>
  )
}

function RainfallCard() {
  const bars = [12, 18, 24, 31, 28, 42, 38, 55, 48, 61, 44, 33]
  const max = Math.max(...bars)
  return (
    <Card>
      <div className="flex items-center gap-2">
        <div className="grid size-9 place-items-center rounded-xl bg-info/15 text-info">
          <CloudRain className="size-5" />
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold">Today's Rainfall</h3>
          <p className="text-xs text-muted-foreground">Munnar station</p>
        </div>
      </div>
      <div className="mt-4 flex items-baseline gap-1.5">
        <span className="font-display text-3xl font-bold text-info">184</span>
        <span className="text-sm text-muted-foreground">mm · IMD Orange</span>
      </div>
      <div className="mt-4 flex h-20 items-end gap-1.5">
        {bars.map((b, i) => (
          <motion.div
            key={i}
            className="flex-1 rounded-t-md bg-info/40"
            initial={{ height: 0 }}
            animate={{ height: `${(b / max) * 100}%` }}
            transition={{ delay: i * 0.04, duration: 0.5 }}
          />
        ))}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Peak intensity between 2–4 PM correlates with feeder trips.
      </p>
    </Card>
  )
}
