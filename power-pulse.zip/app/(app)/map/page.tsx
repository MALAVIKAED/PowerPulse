"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { MapWrapper } from "@/components/map/map-wrapper"
import { PageHeader, StatusPill } from "@/components/app/ui"
import { outages } from "@/lib/data"
import { timeAgo } from "@/lib/status"
import { ArrowUpRight, Filter } from "lucide-react"

type FilterKey = "all" | "outage" | "restoring" | "restored"

const filters: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "outage", label: "Outage" },
  { key: "restoring", label: "Restoring" },
  { key: "restored", label: "Restored" },
]

export default function MapPage() {
  const [filter, setFilter] = useState<FilterKey>("all")
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const filtered = useMemo(
    () => (filter === "all" ? outages : outages.filter((o) => o.status === filter)),
    [filter],
  )

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Live Outage Map"
        subtitle="Real-time power status across Kerala districts during monsoon operations."
      />

      <div className="flex flex-wrap items-center gap-2">
        <Filter className="h-4 w-4 text-muted-foreground" aria-hidden />
        {filters.map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setFilter(f.key)}
            className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors ${
              filter === f.key
                ? "border-primary bg-primary/15 text-primary"
                : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
        <div className="h-[420px] overflow-hidden rounded-2xl border border-border glass sm:h-[560px]">
          <MapWrapper outages={filtered} selectedId={selectedId} onSelect={setSelectedId} />
        </div>

        <div className="flex max-h-[560px] flex-col gap-3 overflow-y-auto pr-1">
          {filtered.map((o) => {
            const active = selectedId === o.id
            return (
              <button
                key={o.id}
                type="button"
                onMouseEnter={() => setSelectedId(o.id)}
                onClick={() => setSelectedId(o.id)}
                className={`rounded-2xl border p-4 text-left transition-colors ${
                  active ? "border-primary bg-primary/5" : "border-border glass hover:border-primary/40"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium text-foreground">{o.area}</p>
                    <p className="text-sm text-muted-foreground">
                      {o.district} · {o.affectedCustomers.toLocaleString("en-IN")} affected
                    </p>
                  </div>
                  <StatusPill status={o.status} />
                </div>
                <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                  <span>Reported {timeAgo(o.reportedAt)}</span>
                  <Link
                    href={`/outage/${o.id}`}
                    className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Details <ArrowUpRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </button>
            )
          })}
          {filtered.length === 0 && (
            <p className="rounded-2xl border border-border glass p-6 text-center text-sm text-muted-foreground">
              No outages match this filter.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
