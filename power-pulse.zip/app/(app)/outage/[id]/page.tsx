"use client"

import { use } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { LivePowerStatus } from "@/components/app/live-status"
import { AiEstimation } from "@/components/app/ai-estimation"
import { OutageTimeline } from "@/components/app/outage-timeline"
import { AuthorityCard } from "@/components/app/authority-card"
import { GlassCard, Stat } from "@/components/app/ui"
import { outages } from "@/lib/data"
import { ArrowLeft, Users, MapPin, Zap, CloudRain } from "lucide-react"

export default function OutageDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const outage = outages.find((o) => o.id === id)
  if (!outage) notFound()

  return (
    <div className="flex flex-col gap-5">
      <Link
        href="/map"
        className="inline-flex w-fit items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to map
      </Link>

      <div className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        <div className="flex flex-col gap-5">
          <LivePowerStatus outage={outage} />

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <Stat icon={Users} label="Affected" value={outage.affected.toLocaleString("en-IN")} />
            <Stat icon={MapPin} label="District" value={outage.district} />
            <Stat icon={Zap} label="Feeder" value={outage.feeder} />
            <Stat icon={CloudRain} label="Cause" value={outage.cause} />
          </div>

          <AiEstimation outage={outage} />
          <OutageTimeline />
        </div>

        <div className="flex flex-col gap-5">
          <AuthorityCard outage={outage} />
        </div>
      </div>
    </div>
  )
}
