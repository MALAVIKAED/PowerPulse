import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Poppins } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-poppins',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'PowerPulse — Know Why. Know Who. Know When.',
  description:
    'Intelligent monsoon power outage transparency platform for Kerala. Track outages, repair crews, restoration times, and emergency resources in real time.',
  generator: 'v0.app',
  keywords: [
    'PowerPulse',
    'power outage',
    'Kerala',
    'monsoon',
    'disaster management',
    'smart governance',
    'KSEB',
  ],
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0b1220',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      className={`dark bg-background ${inter.variable} ${poppins.variable}`}
    >
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
