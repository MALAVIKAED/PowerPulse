import { LandingNav, LandingFooter } from '@/components/landing/nav-footer'
import { Hero } from '@/components/landing/hero'
import {
  StatsSection,
  FeaturesSection,
  TestimonialsSection,
  CtaSection,
} from '@/components/landing/sections'
import { ChatWidget } from '@/components/chat/chat-widget'

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <LandingNav />
      <main>
        <Hero />
        <StatsSection />
        <div id="features">
          <FeaturesSection />
        </div>
        <div id="trust">
          <TestimonialsSection />
        </div>
        <CtaSection />
      </main>
      <LandingFooter />
      <ChatWidget />
    </div>
  )
}
