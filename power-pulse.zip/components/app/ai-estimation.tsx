'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { BrainCircuit, CloudRain, TreePine } from 'lucide-react'
import type { Outage } from '@/lib/data'
import { timeUntil } from '@/lib/status'

export function AiEstimation({ outage }: { outage: Outage }) {
  const [progress, setProgress] = useState(0)
  const confidence = outage.confidence
  const radius = 52
  const circumference = 2 * Math.PI * radius

  useEffect(() => {
    const t = setTimeout(() => setProgress(confidence), 200)
    return () => clearTimeout(t)
  }, [confidence])

  return (
    <div className="glass relative overflow-hidden rounded-2xl p-6">
      <div className="mb-5 flex items-center gap-2">
        <div className="grid size-9 place-items-center rounded-xl bg-primary/15 text-primary">
          <BrainCircuit className="size-5" />
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold">
            AI Restoration Estimate
          </h3>
          <p className="text-xs text-muted-foreground">
            Predictive model · monsoon-tuned
          </p>
        </div>
      </div>

      <div className="flex items-center gap-6">
        {/* Circular confidence gauge */}
        <div className="relative grid size-32 shrink-0 place-items-center">
          <svg className="size-32 -rotate-90" viewBox="0 0 128 128">
            <circle
              cx="64"
              cy="64"
              r={radius}
              fill="none"
              stroke="var(--color-muted)"
              strokeWidth="10"
            />
            <motion.circle
              cx="64"
              cy="64"
              r={radius}
              fill="none"
              stroke="var(--color-primary)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{
                strokeDashoffset:
                  circumference - (progress / 100) * circumference,
              }}
              transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="font-display text-2xl font-bold">
              {confidence}%
            </span>
            <span className="text-[10px] text-muted-foreground">confidence</span>
          </div>
        </div>

        <div className="flex-1">
          <p className="text-xs text-muted-foreground">Estimated Restoration</p>
          <p className="font-display text-3xl font-bold tracking-tight text-primary">
            {outage.status === 'restored'
              ? 'Restored'
              : timeUntil(outage.estimatedRestoration)}
          </p>
          <div className="mt-4 space-y-2">
            <Reason icon={TreePine} label="Primary reason" value={outage.cause} />
            <Reason
              icon={CloudRain}
              label="Weather impact"
              value={outage.severity === 'critical' ? 'High' : 'Moderate'}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

function Reason({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof TreePine
  label: string
  value: string
}) {
  return (
    <div className="flex items-center gap-2.5">
      <Icon className="size-4 text-muted-foreground" />
      <div className="min-w-0">
        <span className="text-xs text-muted-foreground">{label}: </span>
        <span className="text-xs font-medium">{value}</span>
      </div>
    </div>
  )
}
