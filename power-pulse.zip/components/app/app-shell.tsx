'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Bell, Menu, Phone, Search, X } from 'lucide-react'
import { Logo } from '@/components/logo'
import { ThemeToggle } from './theme-toggle'
import { primaryNav, secondaryNav, bottomNav } from './nav-items'
import { ChatWidget } from '@/components/chat/chat-widget'
import { notifications } from '@/lib/data'
import { cn } from '@/lib/utils'

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname()
  return (
    <nav className="flex flex-1 flex-col gap-1">
      <p className="px-3 pb-1 pt-2 text-[10px] font-semibold tracking-[0.18em] text-muted-foreground uppercase">
        Overview
      </p>
      {primaryNav.map((item) => {
        const active = pathname === item.href
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              'group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
              active
                ? 'bg-primary/12 text-primary'
                : 'text-muted-foreground hover:bg-accent hover:text-foreground',
            )}
          >
            {active && (
              <motion.span
                layoutId="nav-active"
                className="absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r-full bg-primary"
              />
            )}
            <item.icon className="size-4.5" />
            {item.label}
          </Link>
        )
      })}
      <p className="px-3 pb-1 pt-4 text-[10px] font-semibold tracking-[0.18em] text-muted-foreground uppercase">
        Account
      </p>
      {secondaryNav.map((item) => {
        const active = pathname === item.href
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
              active
                ? 'bg-primary/12 text-primary'
                : 'text-muted-foreground hover:bg-accent hover:text-foreground',
            )}
          >
            <item.icon className="size-4.5" />
            {item.label}
          </Link>
        )
      })}
    </nav>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const pathname = usePathname()
  const unread = notifications.filter((n) => !n.read).length

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-border bg-sidebar p-4 lg:flex">
        <div className="px-2 pb-4">
          <Link href="/">
            <Logo />
          </Link>
        </div>
        <NavLinks />
        <Link
          href="/help"
          className="mt-2 flex items-center gap-3 rounded-xl bg-power-off/12 px-3 py-3 text-sm font-medium text-power-off transition-colors hover:bg-power-off/20"
        >
          <Phone className="size-4.5" />
          Emergency: 1912
        </Link>
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 32 }}
              className="fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-border bg-sidebar p-4 lg:hidden"
            >
              <div className="flex items-center justify-between px-2 pb-4">
                <Link href="/" onClick={() => setMobileOpen(false)}>
                  <Logo />
                </Link>
                <button
                  onClick={() => setMobileOpen(false)}
                  aria-label="Close menu"
                  className="grid size-8 place-items-center rounded-lg hover:bg-accent"
                >
                  <X className="size-5" />
                </button>
              </div>
              <NavLinks onNavigate={() => setMobileOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main column */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border glass px-4 sm:px-6">
          <button
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
            className="grid size-9 place-items-center rounded-xl border border-border text-muted-foreground hover:bg-accent lg:hidden"
          >
            <Menu className="size-5" />
          </button>

          <div className="relative hidden max-w-md flex-1 sm:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              placeholder="Search areas, outages, crews..."
              className="w-full rounded-xl border border-border bg-background/50 py-2 pl-9 pr-3 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/40"
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />
            <Link
              href="/notifications"
              aria-label="Notifications"
              className="relative grid size-9 place-items-center rounded-xl border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              <Bell className="size-4.5" />
              {unread > 0 && (
                <span className="absolute -right-1 -top-1 grid size-4.5 place-items-center rounded-full bg-power-off text-[10px] font-bold text-white">
                  {unread}
                </span>
              )}
            </Link>
            <Link href="/profile" className="flex items-center gap-2 rounded-xl border border-border py-1 pl-1 pr-2.5 transition-colors hover:bg-accent">
              <span className="grid size-7 place-items-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">
                AK
              </span>
              <span className="hidden text-sm font-medium sm:block">Aravind</span>
            </Link>
          </div>
        </header>

        <main className="min-h-[calc(100vh-4rem)] p-4 pb-24 sm:p-6 lg:pb-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t border-border glass px-2 py-2 lg:hidden">
        {bottomNav.map((item) => {
          const active = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-1 flex-col items-center gap-0.5 rounded-lg py-1.5 text-[11px] font-medium transition-colors',
                active ? 'text-primary' : 'text-muted-foreground',
              )}
            >
              <item.icon className="size-5" />
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Sticky emergency button (mobile) */}
      <a
        href="tel:1912"
        aria-label="Call KSEB emergency helpline 1912"
        className="fixed bottom-20 left-4 z-40 flex items-center gap-2 rounded-full bg-power-off px-4 py-3 text-sm font-semibold text-white shadow-xl shadow-power-off/30 lg:hidden"
      >
        <Phone className="size-4" />
        1912
      </a>

      <ChatWidget />
    </div>
  )
}
