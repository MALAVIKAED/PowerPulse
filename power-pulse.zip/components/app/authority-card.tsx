'use client'

import { Building2, Phone, Truck, User, Wrench } from 'lucide-react'
import type { Outage } from '@/lib/data'
import { crewStatusMeta } from '@/lib/status'
import { cn } from '@/lib/utils'

export function AuthorityCard({ outage }: { outage: Outage }) {
  const crew = crewStatusMeta[outage.crewStatus]
  const rows = [
    { icon: Building2, label: 'Section Office', value: outage.section },
    { icon: User, label: 'Assistant Engineer', value: outage.engineer },
    { icon: Wrench, label: 'Maintenance Crew', value: outage.crewNumber },
    { icon: Truck, label: 'Repair Vehicle', value: outage.vehicle },
  ]

  return (
    <div className="glass rounded-2xl p-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-display text-sm font-semibold">
            Responsible Authority
          </h3>
          <p className="text-xs text-muted-foreground">
            Accountable for this restoration
          </p>
        </div>
        <span
          className={cn(
            'rounded-full border px-2.5 py-0.5 text-xs font-semibold',
            crew.tone,
          )}
        >
          {crew.label}
        </span>
      </div>

      <div className="space-y-1">
        {rows.map((r) => (
          <div
            key={r.label}
            className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-accent/60"
          >
            <div className="grid size-9 place-items-center rounded-lg bg-accent text-muted-foreground">
              <r.icon className="size-4.5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted-foreground">{r.label}</p>
              <p className="truncate text-sm font-medium">{r.value}</p>
            </div>
          </div>
        ))}
      </div>

      <a
        href={`tel:${outage.contact.replace(/\s/g, '')}`}
        className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 active:translate-y-px"
      >
        <Phone className="size-4" />
        Call Section Office · {outage.contact}
      </a>
    </div>
  )
}
