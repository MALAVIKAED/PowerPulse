'use client'

import { motion } from 'framer-motion'
import { Clock, MapPin, Timer, Zap } from 'lucide-react'
import type { Outage } from '@/lib/data'
import {
  durationSince,
  formatTime,
  outageStatusMeta,
  timeUntil,
} from '@/lib/status'
import { cn } from '@/lib/utils'

export function LivePowerStatus({ outage }: { outage: Outage }) {
  const meta = outageStatusMeta[outage.status]
  const isOut = outage.status !== 'restored'

  return (
    <div className="glass relative overflow-hidden rounded-2xl p-6">
      <div
        className={cn(
          'absolute -right-16 -top-16 size-52 rounded-full blur-3xl',
          isOut ? 'bg-power-off/15' : 'bg-power-on/15',
        )}
      />
      <div className="relative">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">
            Current Power Status
          </span>
          <span
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold',
              meta.bg,
              meta.text,
            )}
          >
            <span className={cn('size-1.5 rounded-full', meta.dot)} />
            {meta.label}
          </span>
        </div>

        <div className="mt-5 flex items-center gap-4">
          {/* Voltage / pulse indicator */}
          <div
            className={cn(
              'grid size-16 shrink-0 place-items-center rounded-2xl',
              isOut ? 'bg-power-off/12 pulse-off' : 'bg-power-on/12 pulse-on',
            )}
          >
            <Zap
              className={cn(
                'size-7',
                isOut ? 'text-power-off' : 'text-power-on',
              )}
              fill="currentColor"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="size-3.5" /> {outage.area}, {outage.district}
            </div>
            <div className="font-display text-2xl font-bold">
              {isOut ? 'Power Interrupted' : 'Power Restored'}
            </div>
            <div className="mt-0.5 text-sm text-muted-foreground">
              {outage.affectedCustomers.toLocaleString('en-IN')} customers
              affected
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <Metric
            icon={Clock}
            label="Time Out"
            value={formatTime(outage.wentOutAt)}
          />
          <Metric
            icon={Timer}
            label="Duration"
            value={durationSince(outage.wentOutAt)}
          />
          <Metric
            icon={Zap}
            label="Est. Restore"
            value={
              outage.status === 'restored'
                ? 'Done'
                : timeUntil(outage.estimatedRestoration)
            }
          />
        </div>

        {/* Animated voltage bars */}
        <div className="mt-5 flex items-end gap-1">
          {Array.from({ length: 28 }).map((_, i) => (
            <motion.span
              key={i}
              className={cn(
                'flex-1 rounded-full',
                isOut ? 'bg-power-off/40' : 'bg-power-on/50',
              )}
              initial={{ height: 4 }}
              animate={{
                height: isOut
                  ? [4, 4 + (i % 3) * 3, 4]
                  : [6, 10 + (i % 5) * 4, 6],
              }}
              transition={{
                duration: 1.2,
                repeat: Number.POSITIVE_INFINITY,
                delay: i * 0.04,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Clock
  label: string
  value: string
}) {
  return (
    <div className="rounded-xl border border-border bg-background/40 p-3">
      <Icon className="size-4 text-muted-foreground" />
      <div className="mt-2 font-display text-lg font-bold tracking-tight">
        {value}
      </div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  )
}
