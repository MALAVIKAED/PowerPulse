import {
  LayoutDashboard,
  Map,
  FileText,
  LifeBuoy,
  BarChart3,
  Bell,
  User,
  Settings,
  HelpCircle,
  type LucideIcon,
} from 'lucide-react'

export interface NavItem {
  label: string
  href: string
  icon: LucideIcon
}

export const primaryNav: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Power Map', href: '/map', icon: Map },
  { label: 'Reports', href: '/reports', icon: FileText },
  { label: 'Resources', href: '/resources', icon: LifeBuoy },
  { label: 'Analytics', href: '/analytics', icon: BarChart3 },
  { label: 'Notifications', href: '/notifications', icon: Bell },
]

export const secondaryNav: NavItem[] = [
  { label: 'Profile', href: '/profile', icon: User },
  { label: 'Settings', href: '/settings', icon: Settings },
  { label: 'Help', href: '/help', icon: HelpCircle },
]

// Condensed set for the mobile bottom navigation bar.
export const bottomNav: NavItem[] = [
  { label: 'Home', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Map', href: '/map', icon: Map },
  { label: 'Report', href: '/reports', icon: FileText },
  { label: 'Alerts', href: '/notifications', icon: Bell },
]
