'use client'

import { motion } from 'framer-motion'
import { Check, Loader2 } from 'lucide-react'
import { outageTimeline } from '@/lib/data'
import { cn } from '@/lib/utils'

export function OutageTimeline() {
  return (
    <div className="glass rounded-2xl p-6">
      <h3 className="font-display text-sm font-semibold">Restoration Timeline</h3>
      <p className="mb-5 text-xs text-muted-foreground">
        Every stage from complaint to restoration
      </p>
      <ol className="relative">
        {outageTimeline.map((stage, i) => {
          const isLast = i === outageTimeline.length - 1
          return (
            <li key={stage.key} className="relative flex gap-4 pb-6 last:pb-0">
              {!isLast && (
                <span
                  className={cn(
                    'absolute left-[15px] top-8 h-full w-0.5',
                    stage.done ? 'bg-power-on/50' : 'bg-border',
                  )}
                />
              )}
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.08, type: 'spring', stiffness: 300 }}
                className={cn(
                  'relative z-10 grid size-8 shrink-0 place-items-center rounded-full border-2',
                  stage.active
                    ? 'border-warning bg-warning/15 text-warning pulse-off'
                    : stage.done
                      ? 'border-power-on bg-power-on/15 text-power-on'
                      : 'border-border bg-background text-muted-foreground',
                )}
              >
                {stage.active ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : stage.done ? (
                  <Check className="size-4" />
                ) : (
                  <span className="size-2 rounded-full bg-current" />
                )}
              </motion.span>
              <div className="pt-1">
                <p
                  className={cn(
                    'text-sm font-medium',
                    !stage.done && !stage.active && 'text-muted-foreground',
                  )}
                >
                  {stage.label}
                </p>
                <p className="text-xs text-muted-foreground">
                  {stage.time ?? 'Pending'}
                  {stage.active && ' · in progress'}
                </p>
              </div>
            </li>
          )
        })}
      </ol>
    </div>
  )
}
