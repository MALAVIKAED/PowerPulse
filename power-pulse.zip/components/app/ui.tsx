'use client'

import { motion } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'
import { AnimatedCounter } from '@/components/animated-counter'
import { cn } from '@/lib/utils'
import type { StatCard as StatCardType, OutageStatus } from '@/lib/data'
import { outageStatusMeta } from '@/lib/status'

export function PageHeader({
  title,
  subtitle,
  icon: Icon,
  action,
}: {
  title: string
  subtitle?: string
  icon?: LucideIcon
  action?: React.ReactNode
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="grid size-11 place-items-center rounded-2xl bg-primary/12 text-primary">
            <Icon className="size-5.5" />
          </div>
        )}
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-0.5 text-sm text-muted-foreground text-pretty">
              {subtitle}
            </p>
          )}
        </div>
      </div>
      {action}
    </div>
  )
}

export function Badge({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold',
        className,
      )}
    >
      {children}
    </span>
  )
}

const toneColor: Record<string, string> = {
  info: 'text-info',
  'power-on': 'text-power-on',
  'power-off': 'text-power-off',
  warning: 'text-warning',
}
const toneBg: Record<string, string> = {
  info: 'bg-info/12',
  'power-on': 'bg-power-on/12',
  'power-off': 'bg-power-off/12',
  warning: 'bg-warning/12',
}

export function StatTile({
  stat,
  icon: Icon,
  index = 0,
}: {
  stat: StatCardType
  icon: LucideIcon
  index?: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      className="glass rounded-2xl p-5"
    >
      <div className="flex items-start justify-between">
        <div
          className={cn(
            'grid size-10 place-items-center rounded-xl',
            toneBg[stat.tone],
            toneColor[stat.tone],
          )}
        >
          <Icon className="size-5" />
        </div>
        <span
          className={cn(
            'text-xs font-medium',
            stat.trendUp ? 'text-power-on' : 'text-muted-foreground',
          )}
        >
          {stat.trend}
        </span>
      </div>
      <div
        className={cn(
          'mt-4 font-display text-3xl font-bold tracking-tight',
          toneColor[stat.tone],
        )}
      >
        {stat.prefix}
        <AnimatedCounter value={stat.value} />
        {stat.suffix}
      </div>
      <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
    </motion.div>
  )
}

export function Card({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn('glass rounded-2xl p-5', className)}>{children}</div>
  )
}

export function GlassCard({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn('glass rounded-2xl p-5', className)}>{children}</div>
  )
}

export function StatusPill({ status }: { status: OutageStatus }) {
  const meta = outageStatusMeta[status]
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold',
        meta.bg,
        meta.text,
      )}
    >
      <span className={cn('size-1.5 rounded-full', meta.dot)} />
      {meta.label}
    </span>
  )
}

export function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon
  label: string
  value: string
}) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-4" />
        <span className="text-xs font-medium uppercase tracking-wide">
          {label}
        </span>
      </div>
      <p className="mt-2 font-display text-lg font-semibold text-foreground">
        {value}
      </p>
    </div>
  )
}
