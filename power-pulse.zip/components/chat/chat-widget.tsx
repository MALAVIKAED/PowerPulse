'use client'

import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Bot, Send, Sparkles, X } from 'lucide-react'
import { chatSuggestions } from '@/lib/data'
import { cn } from '@/lib/utils'

interface Message {
  id: number
  role: 'user' | 'bot'
  text: string
}

// Simple canned-response assistant for the demo (no backend).
function getReply(q: string): string {
  const t = q.toLowerCase()
  if (t.includes('why'))
    return 'Power in Munnar Town is out due to a tree fall on the 11kV feeder. High winds during the monsoon uprooted a tree onto the distribution line.'
  if (t.includes('when') || t.includes('return') || t.includes('restore'))
    return 'Estimated restoration for your area is about 2 hours 15 minutes, with 92% confidence. Crew CREW-07 is currently on-site handling tree removal.'
  if (t.includes('charging') || t.includes('charge'))
    return 'The nearest charging station is the Munnar Community Charging Hub, 0.8 km away. It is open and powered by backup generators.'
  if (t.includes('hospital'))
    return 'Tata General Hospital is 1.4 km away, open, and running on full power. It is the nearest facility with electricity.'
  if (t.includes('status'))
    return 'Current status for Munnar Town: RESTORING. Went out 2h 22m ago. Crew is repairing now. 1,240 customers affected.'
  return 'I can help with outage causes, restoration times, and nearby emergency resources like charging stations and hospitals. Try one of the suggested questions.'
}

export function ChatWidget() {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: 'bot',
      text: 'Hi! I am the PowerPulse assistant. Ask me anything about your outage or nearby resources.',
    },
  ])
  const [typing, setTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 9e9, behavior: 'smooth' })
  }, [messages, typing, open])

  function send(text: string) {
    const q = text.trim()
    if (!q) return
    const userMsg: Message = { id: Date.now(), role: 'user', text: q }
    setMessages((m) => [...m, userMsg])
    setInput('')
    setTyping(true)
    setTimeout(() => {
      setTyping(false)
      setMessages((m) => [
        ...m,
        { id: Date.now() + 1, role: 'bot', text: getReply(q) },
      ])
    }, 900)
  }

  return (
    <>
      {/* Floating button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.6, type: 'spring', stiffness: 260, damping: 20 }}
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? 'Close assistant' : 'Open PowerPulse assistant'}
        className="fixed bottom-20 right-4 z-[60] grid size-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-xl shadow-primary/30 transition-transform hover:scale-105 active:scale-95 md:bottom-6 md:right-6"
      >
        <AnimatePresence mode="wait" initial={false}>
          {open ? (
            <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="size-6" />
            </motion.span>
          ) : (
            <motion.span key="bot" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <Bot className="size-6" />
            </motion.span>
          )}
        </AnimatePresence>
        {!open && (
          <span className="pulse-on absolute inset-0 rounded-full" />
        )}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 300, damping: 26 }}
            className="glass-strong fixed bottom-36 right-4 z-[60] flex h-[30rem] w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-3xl shadow-2xl md:bottom-24 md:right-6"
          >
            {/* Header */}
            <div className="flex items-center gap-3 border-b border-border bg-primary/10 px-4 py-3">
              <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
                <Sparkles className="size-4.5" />
              </div>
              <div className="leading-tight">
                <p className="font-display text-sm font-semibold">
                  PowerPulse Assistant
                </p>
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="size-1.5 rounded-full bg-power-on" /> Online
                </p>
              </div>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={cn(
                    'flex',
                    m.role === 'user' ? 'justify-end' : 'justify-start',
                  )}
                >
                  <div
                    className={cn(
                      'max-w-[85%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed',
                      m.role === 'user'
                        ? 'rounded-br-sm bg-primary text-primary-foreground'
                        : 'rounded-bl-sm bg-accent text-accent-foreground',
                    )}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {typing && (
                <div className="flex justify-start">
                  <div className="flex gap-1 rounded-2xl rounded-bl-sm bg-accent px-4 py-3">
                    {[0, 1, 2].map((i) => (
                      <motion.span
                        key={i}
                        className="size-1.5 rounded-full bg-muted-foreground"
                        animate={{ y: [0, -4, 0] }}
                        transition={{ duration: 0.6, repeat: Number.POSITIVE_INFINITY, delay: i * 0.15 }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Suggestions */}
            <div className="flex flex-wrap gap-1.5 px-4 pb-2">
              {chatSuggestions.slice(0, 3).map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-full border border-border bg-background/50 px-2.5 py-1 text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault()
                send(input)
              }}
              className="flex items-center gap-2 border-t border-border p-3"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (
                    e.key === 'Enter' &&
                    !e.nativeEvent.isComposing &&
                    e.keyCode !== 229
                  ) {
                    e.preventDefault()
                    send(input)
                  }
                }}
                placeholder="Ask about your outage..."
                className="min-w-0 flex-1 rounded-xl border border-border bg-background/60 px-3 py-2 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/40"
              />
              <button
                type="submit"
                aria-label="Send message"
                className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground transition-all hover:brightness-110 active:scale-95"
              >
                <Send className="size-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
