'use client'

import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { ArrowRight, MapPin, Radio } from 'lucide-react'
import { RainBackground } from './rain-background'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      {/* Background image + monsoon animation */}
      <div className="absolute inset-0">
        <Image
          src="/kerala-monsoon-hero.png"
          alt="Kerala high range hills during heavy monsoon with power transmission lines"
          fill
          priority
          className="object-cover object-center opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background/50" />
      </div>
      <RainBackground />

      <div className="relative mx-auto flex min-h-[92vh] max-w-6xl flex-col items-center justify-center px-5 py-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-border glass px-4 py-1.5 text-sm"
        >
          <span className="relative flex size-2">
            <span className="pulse-on absolute inline-flex size-2 rounded-full bg-power-on" />
            <span className="relative inline-flex size-2 rounded-full bg-power-on" />
          </span>
          <span className="text-muted-foreground">
            Live monitoring across the Idukki High Range
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.05 }}
          className="font-display text-4xl font-extrabold tracking-tight text-balance sm:text-6xl lg:text-7xl"
        >
          Transparent Power Restoration
          <br className="hidden sm:block" />{' '}
          <span className="bg-gradient-to-r from-info via-primary to-power-on bg-clip-text text-transparent">
            During Every Storm
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-pretty text-muted-foreground"
        >
          Know why your electricity went off, who is fixing it, when it will
          return, and where to find emergency resources — all in one place.
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="mt-3 font-display text-sm font-semibold tracking-[0.3em] text-primary uppercase"
        >
          Know Why. Know Who. Know When.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-9 flex flex-col gap-3 sm:flex-row"
        >
          <Link
            href="/dashboard"
            className="group inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:shadow-xl hover:shadow-primary/40 hover:brightness-110 active:translate-y-px"
          >
            <Radio className="size-4.5" />
            View Live Dashboard
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <Link
            href="/reports"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-border glass px-6 py-3 font-semibold transition-all hover:bg-accent active:translate-y-px"
          >
            <MapPin className="size-4.5" />
            Report Outage
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
