'use client'

import Link from 'next/link'
import { Logo } from '@/components/logo'

export function LandingNav() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:pt-4">
      <div className="mx-auto flex max-w-6xl items-center justify-between rounded-2xl border border-border glass px-4 py-2.5 sm:px-5">
        <Logo />
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <a href="#features" className="transition-colors hover:text-foreground">
            Features
          </a>
          <a href="#trust" className="transition-colors hover:text-foreground">
            Trust
          </a>
          <Link href="/map" className="transition-colors hover:text-foreground">
            Live Map
          </Link>
        </nav>
        <Link
          href="/dashboard"
          className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 active:translate-y-px"
        >
          Open App
        </Link>
      </div>
    </header>
  )
}

const footerCols = [
  {
    title: 'Platform',
    links: ['Dashboard', 'Live Map', 'Analytics', 'Resources'],
  },
  {
    title: 'Community',
    links: ['Report Outage', 'Notifications', 'Help Center', 'Contact'],
  },
  {
    title: 'Authority',
    links: ['KSEB Idukki', 'Section Offices', 'Disaster Management', 'IMD Alerts'],
  },
]

export function LandingFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto max-w-6xl px-5 py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              An intelligent monsoon power outage transparency platform for the
              Kerala High Range.
            </p>
          </div>
          {footerCols.map((col) => (
            <div key={col.title}>
              <h4 className="font-display text-sm font-semibold">{col.title}</h4>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="transition-colors hover:text-foreground">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} PowerPulse. A civic-tech demo project.</p>
          <p>Know Why. Know Who. Know When.</p>
        </div>
      </div>
    </footer>
  )
}
