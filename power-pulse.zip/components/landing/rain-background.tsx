'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'

// Animated monsoon backdrop: falling rain streaks + occasional lightning flash.
export function RainBackground() {
  const drops = useMemo(
    () =>
      Array.from({ length: 60 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 2,
        duration: 0.6 + Math.random() * 0.8,
        height: 40 + Math.random() * 60,
        opacity: 0.15 + Math.random() * 0.35,
      })),
    [],
  )

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 overflow-hidden"
    >
      {/* Rain */}
      {drops.map((d) => (
        <span
          key={d.id}
          className="absolute top-[-10%] w-px bg-gradient-to-b from-transparent via-info/60 to-transparent"
          style={{
            left: `${d.left}%`,
            height: `${d.height}px`,
            opacity: d.opacity,
            animation: `rain-fall ${d.duration}s linear ${d.delay}s infinite`,
          }}
        />
      ))}

      {/* Lightning flashes */}
      <motion.div
        className="absolute inset-0 bg-info/10"
        animate={{ opacity: [0, 0, 0, 0.5, 0, 0.2, 0] }}
        transition={{
          duration: 6,
          times: [0, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7],
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 4,
        }}
      />

      {/* Drifting clouds */}
      <motion.div
        className="absolute -top-20 left-0 h-64 w-[140%] rounded-full bg-primary/10 blur-3xl"
        animate={{ x: ['-10%', '10%', '-10%'] }}
        transition={{ duration: 22, repeat: Number.POSITIVE_INFINITY, ease: 'easeInOut' }}
      />
    </div>
  )
}
