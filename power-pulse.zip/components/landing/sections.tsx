'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Activity,
  Bell,
  BrainCircuit,
  MapPinned,
  ShieldCheck,
  Users,
  Quote,
} from 'lucide-react'
import { AnimatedCounter } from '@/components/animated-counter'
import { landingStats } from '@/lib/data'
import { cn } from '@/lib/utils'

const toneMap: Record<string, string> = {
  info: 'text-info',
  'power-on': 'text-power-on',
  'power-off': 'text-power-off',
  warning: 'text-warning',
}

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0 },
}

export function StatsSection() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {landingStats.map((s, i) => (
          <motion.div
            key={s.label}
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            className="glass rounded-2xl p-5 shadow-lg shadow-black/5"
          >
            <div
              className={cn(
                'font-display text-4xl font-bold tracking-tight',
                toneMap[s.tone],
              )}
            >
              <AnimatedCounter value={s.value} />
              {s.suffix}
            </div>
            <p className="mt-1 text-sm font-medium">{s.label}</p>
            <p className="mt-0.5 text-xs text-muted-foreground">{s.trend}</p>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

const features = [
  {
    icon: BrainCircuit,
    title: 'AI Restoration Estimates',
    desc: 'Predictive ETAs with confidence scores, tuned for weather and cause.',
    tone: 'text-primary',
  },
  {
    icon: MapPinned,
    title: 'Live Outage Map',
    desc: 'See outages, crews, hospitals, and charging points on one map.',
    tone: 'text-info',
  },
  {
    icon: Activity,
    title: 'Transparent Timeline',
    desc: 'Track every stage from complaint to restoration in real time.',
    tone: 'text-power-on',
  },
  {
    icon: Users,
    title: 'Community Reports',
    desc: 'Citizens flag hazards; verified reports accelerate response.',
    tone: 'text-warning',
  },
  {
    icon: ShieldCheck,
    title: 'Accountable Authority',
    desc: 'Know the exact section office, engineer, and crew responsible.',
    tone: 'text-primary',
  },
  {
    icon: Bell,
    title: 'Smart Alerts',
    desc: 'Weather, landslide, and restoration notifications for your area.',
    tone: 'text-info',
  },
]

export function FeaturesSection() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="font-display text-3xl font-bold tracking-tight text-balance sm:text-4xl">
          Every question, answered in one place
        </h2>
        <p className="mt-3 text-muted-foreground text-pretty">
          PowerPulse turns confusion during an outage into clarity, trust, and
          faster restoration.
        </p>
      </div>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.5, delay: i * 0.06 }}
            className="group glass rounded-2xl p-6 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10"
          >
            <div className="mb-4 grid size-11 place-items-center rounded-xl bg-accent">
              <f.icon className={cn('size-5.5', f.tone)} />
            </div>
            <h3 className="font-display text-lg font-semibold">{f.title}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              {f.desc}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

const testimonials = [
  {
    quote:
      'For the first time during a monsoon outage, I knew exactly why the power was gone and when it would return. No more guessing.',
    name: 'Lakshmi Nair',
    role: 'Resident, Munnar',
  },
  {
    quote:
      'PowerPulse lets our section office communicate crew status transparently. Complaint calls dropped by half.',
    name: 'Er. Anand Kumar',
    role: 'Assistant Engineer, KSEB',
  },
  {
    quote:
      'The nearest charging station and hospital map was a lifesaver when our village went dark for six hours.',
    name: 'Jose Mathew',
    role: 'Volunteer, Vagamon',
  },
]

export function TestimonialsSection() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="font-display text-3xl font-bold tracking-tight text-balance sm:text-4xl">
          Trusted by citizens and officials
        </h2>
      </div>
      <div className="mt-12 grid gap-4 lg:grid-cols-3">
        {testimonials.map((t, i) => (
          <motion.figure
            key={t.name}
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            className="glass flex flex-col rounded-2xl p-6"
          >
            <Quote className="size-6 text-primary/60" />
            <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-pretty">
              {t.quote}
            </blockquote>
            <figcaption className="mt-4 border-t border-border pt-4">
              <div className="font-semibold">{t.name}</div>
              <div className="text-xs text-muted-foreground">{t.role}</div>
            </figcaption>
          </motion.figure>
        ))}
      </div>
    </section>
  )
}

export function CtaSection() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="glass-strong relative overflow-hidden rounded-3xl px-6 py-14 text-center sm:px-12"
      >
        <div className="absolute -top-24 left-1/2 size-72 -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative">
          <h2 className="font-display text-3xl font-bold tracking-tight text-balance sm:text-4xl">
            Stay informed before the next storm
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground text-pretty">
            Open the live dashboard to monitor outages, crews, and restoration
            progress across the Kerala High Range.
          </p>
          <Link
            href="/dashboard"
            className="mt-8 inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-7 py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:brightness-110 active:translate-y-px"
          >
            Launch Dashboard
          </Link>
        </div>
      </motion.div>
    </section>
  )
}
