import { Zap } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Logo({
  className,
  showText = true,
}: {
  className?: string
  showText?: boolean
}) {
  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <div className="relative grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/25">
        <Zap className="size-5" fill="currentColor" />
        <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/20" />
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className="font-display text-lg font-bold tracking-tight">
            PowerPulse
          </span>
          <span className="text-[10px] font-medium tracking-[0.2em] text-muted-foreground uppercase">
            Kerala Grid
          </span>
        </div>
      )}
    </div>
  )
}
