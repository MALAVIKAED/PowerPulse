"use client"

import dynamic from "next/dynamic"
import { MapPin } from "lucide-react"
import type { Outage } from "@/lib/data"

const OutageMap = dynamic(() => import("./outage-map").then((m) => m.OutageMap), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-muted/40">
      <div className="flex flex-col items-center gap-2 text-muted-foreground">
        <MapPin className="h-6 w-6 animate-pulse" />
        <span className="text-sm">Loading map…</span>
      </div>
    </div>
  ),
})

export function MapWrapper(props: {
  outages: Outage[]
  selectedId?: string | null
  onSelect?: (id: string) => void
}) {
  return <OutageMap {...props} />
}
