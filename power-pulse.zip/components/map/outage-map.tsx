'use client'

import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { outages, resources } from '@/lib/data'
import { outageStatusMeta, timeUntil } from '@/lib/status'

// Color per outage status (resolved to concrete hex so Leaflet DOM can use it).
const statusColor: Record<string, string> = {
  outage: '#f2545b',
  restoring: '#f0a03c',
  restored: '#3ec98a',
}

const resourceColor = '#4d9bf5'

function pinIcon(color: string, glyph: string) {
  return L.divIcon({
    className: 'pp-marker',
    html: `<div style="
      width:30px;height:30px;border-radius:50% 50% 50% 0;
      background:${color};transform:rotate(-45deg);
      display:grid;place-items:center;
      box-shadow:0 4px 12px rgba(0,0,0,0.4);border:2px solid rgba(255,255,255,0.6)">
      <span style="transform:rotate(45deg);font-size:13px;font-weight:700;color:#0b1220">${glyph}</span>
    </div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30],
  })
}

interface Props {
  filter: 'all' | 'outages' | 'resources'
}

export default function OutageMap({ filter }: Props) {
  const center: [number, number] = [9.85, 77.05]

  return (
    <MapContainer
      center={center}
      zoom={10}
      scrollWheelZoom
      className="size-full"
      zoomControl={false}
    >
      <TileLayer
        attribution='&copy; OpenStreetMap &copy; CARTO'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
      />

      {filter !== 'resources' &&
        outages.map((o) => (
          <div key={o.id}>
            <CircleMarker
              center={[o.lat, o.lng]}
              radius={o.status === 'restored' ? 14 : 22}
              pathOptions={{
                color: statusColor[o.status],
                fillColor: statusColor[o.status],
                fillOpacity: 0.12,
                weight: 1,
              }}
            />
            <Marker
              position={[o.lat, o.lng]}
              icon={pinIcon(statusColor[o.status], '!')}
            >
              <Popup>
                <div style={{ minWidth: 180 }}>
                  <strong style={{ fontSize: 14 }}>{o.area}</strong>
                  <div style={{ fontSize: 12, opacity: 0.8, marginTop: 2 }}>
                    {o.cause}
                  </div>
                  <div style={{ fontSize: 12, marginTop: 6 }}>
                    Status:{' '}
                    <b style={{ color: statusColor[o.status] }}>
                      {outageStatusMeta[o.status].label}
                    </b>
                  </div>
                  <div style={{ fontSize: 12 }}>
                    {o.affectedCustomers.toLocaleString('en-IN')} affected
                  </div>
                  {o.status !== 'restored' && (
                    <div style={{ fontSize: 12 }}>
                      ETA: {timeUntil(o.estimatedRestoration)}
                    </div>
                  )}
                </div>
              </Popup>
            </Marker>
          </div>
        ))}

      {filter !== 'outages' &&
        resources.map((r) => (
          <Marker
            key={r.id}
            position={[r.lat, r.lng]}
            icon={pinIcon(resourceColor, '+')}
          >
            <Popup>
              <div style={{ minWidth: 160 }}>
                <strong style={{ fontSize: 14 }}>{r.name}</strong>
                <div style={{ fontSize: 12, opacity: 0.8, marginTop: 2 }}>
                  {r.area} · {r.distanceKm} km
                </div>
                <div style={{ fontSize: 12, marginTop: 6 }}>
                  {r.open ? 'Open now' : 'Closed'} ·{' '}
                  {r.hasPower ? 'Powered' : 'No power'}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
    </MapContainer>
  )
}
