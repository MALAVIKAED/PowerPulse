// PowerPulse mock data — realistic Kerala High Range (Idukki) monsoon scenario.
// All data is static and demo-only. No backend required.

import type { LucideIcon } from 'lucide-react'
import {
  TreePine,
  Zap,
  Waves,
  CloudRain,
  Cable,
  Mountain,
  Wrench,
  CloudLightning,
} from 'lucide-react'

export type OutageStatus = 'outage' | 'restoring' | 'restored'
export type CrewStatus =
  | 'assigned'
  | 'travelling'
  | 'repairing'
  | 'testing'
  | 'completed'

export interface Outage {
  id: string
  area: string
  district: string
  lat: number
  lng: number
  status: OutageStatus
  cause: string
  causeKey: CauseKey
  severity: 'low' | 'moderate' | 'high' | 'critical'
  affectedCustomers: number
  reportedAt: string // ISO
  wentOutAt: string // ISO
  estimatedRestoration: string // ISO
  confidence: number // %
  section: string
  engineer: string
  crewNumber: string
  vehicle: string
  contact: string
  crewStatus: CrewStatus
}

export type CauseKey =
  | 'tree'
  | 'transformer'
  | 'flood'
  | 'rain'
  | 'pole'
  | 'landslide'
  | 'maintenance'
  | 'lightning'

export interface Cause {
  key: CauseKey
  label: string
  description: string
  icon: LucideIcon
  severity: 'low' | 'moderate' | 'high' | 'critical'
}

export const causes: Cause[] = [
  {
    key: 'tree',
    label: 'Tree Fall',
    description: 'Uprooted trees on distribution lines from high winds.',
    icon: TreePine,
    severity: 'high',
  },
  {
    key: 'transformer',
    label: 'Transformer Failure',
    description: 'Overload or moisture ingress tripped the local transformer.',
    icon: Zap,
    severity: 'critical',
  },
  {
    key: 'flood',
    label: 'Flood',
    description: 'Submerged substation equipment isolated for safety.',
    icon: Waves,
    severity: 'critical',
  },
  {
    key: 'rain',
    label: 'Heavy Rain',
    description: 'Preventive shutdown during extreme rainfall spell.',
    icon: CloudRain,
    severity: 'moderate',
  },
  {
    key: 'pole',
    label: 'Broken Pole',
    description: 'Snapped concrete pole requiring full replacement.',
    icon: Cable,
    severity: 'high',
  },
  {
    key: 'landslide',
    label: 'Landslide',
    description: 'Slope failure damaged the feeder corridor.',
    icon: Mountain,
    severity: 'critical',
  },
  {
    key: 'maintenance',
    label: 'Maintenance',
    description: 'Scheduled monsoon-readiness line maintenance.',
    icon: Wrench,
    severity: 'low',
  },
  {
    key: 'lightning',
    label: 'Lightning Strike',
    description: 'Surge from a direct strike blew line insulators.',
    icon: CloudLightning,
    severity: 'high',
  },
]

export const causeMap = Object.fromEntries(
  causes.map((c) => [c.key, c]),
) as Record<CauseKey, Cause>

// Base time reference for the demo
const now = new Date()
const iso = (minutesAgo: number) =>
  new Date(now.getTime() - minutesAgo * 60_000).toISOString()
const isoAhead = (minutesAhead: number) =>
  new Date(now.getTime() + minutesAhead * 60_000).toISOString()

export const outages: Outage[] = [
  {
    id: 'PP-2041',
    area: 'Munnar Town',
    district: 'Idukki',
    lat: 10.0889,
    lng: 77.0595,
    status: 'restoring',
    cause: 'Tree Fall on 11kV Feeder',
    causeKey: 'tree',
    severity: 'high',
    affectedCustomers: 1240,
    reportedAt: iso(138),
    wentOutAt: iso(142),
    estimatedRestoration: isoAhead(135),
    confidence: 92,
    section: 'Munnar Electrical Section',
    engineer: 'Er. Anand Kumar',
    crewNumber: 'CREW-07',
    vehicle: 'KL-06-AE-4412',
    contact: '+91 486 253 0111',
    crewStatus: 'repairing',
  },
  {
    id: 'PP-2038',
    area: 'Adimali',
    district: 'Idukki',
    lat: 10.0126,
    lng: 76.9558,
    status: 'outage',
    cause: 'Transformer Failure',
    causeKey: 'transformer',
    severity: 'critical',
    affectedCustomers: 2100,
    reportedAt: iso(54),
    wentOutAt: iso(58),
    estimatedRestoration: isoAhead(190),
    confidence: 78,
    section: 'Adimali Electrical Section',
    engineer: 'Er. Meera Nair',
    crewNumber: 'CREW-03',
    vehicle: 'KL-06-AB-8890',
    contact: '+91 486 224 0119',
    crewStatus: 'travelling',
  },
  {
    id: 'PP-2033',
    area: 'Kattappana',
    district: 'Idukki',
    lat: 9.7514,
    lng: 77.1163,
    status: 'restored',
    cause: 'Lightning Strike',
    causeKey: 'lightning',
    severity: 'high',
    affectedCustomers: 860,
    reportedAt: iso(410),
    wentOutAt: iso(415),
    estimatedRestoration: iso(120),
    confidence: 96,
    section: 'Kattappana Electrical Section',
    engineer: 'Er. Sajan Thomas',
    crewNumber: 'CREW-11',
    vehicle: 'KL-06-AC-2210',
    contact: '+91 486 227 0145',
    crewStatus: 'completed',
  },
  {
    id: 'PP-2029',
    area: 'Nedumkandam',
    district: 'Idukki',
    lat: 9.8386,
    lng: 77.2242,
    status: 'outage',
    cause: 'Landslide on Feeder Corridor',
    causeKey: 'landslide',
    severity: 'critical',
    affectedCustomers: 1580,
    reportedAt: iso(26),
    wentOutAt: iso(30),
    estimatedRestoration: isoAhead(300),
    confidence: 64,
    section: 'Nedumkandam Electrical Section',
    engineer: 'Er. Fathima Rasheed',
    crewNumber: 'CREW-05',
    vehicle: 'KL-06-AD-7781',
    contact: '+91 486 262 0177',
    crewStatus: 'assigned',
  },
  {
    id: 'PP-2025',
    area: 'Peerumedu',
    district: 'Idukki',
    lat: 9.5769,
    lng: 76.9739,
    status: 'restoring',
    cause: 'Broken Pole',
    causeKey: 'pole',
    severity: 'high',
    affectedCustomers: 640,
    reportedAt: iso(96),
    wentOutAt: iso(100),
    estimatedRestoration: isoAhead(75),
    confidence: 88,
    section: 'Peerumedu Electrical Section',
    engineer: 'Er. Vishnu Prasad',
    crewNumber: 'CREW-09',
    vehicle: 'KL-06-AE-1120',
    contact: '+91 486 232 0190',
    crewStatus: 'testing',
  },
  {
    id: 'PP-2020',
    area: 'Kumily',
    district: 'Idukki',
    lat: 9.6,
    lng: 77.1667,
    status: 'restored',
    cause: 'Heavy Rain Preventive Shutdown',
    causeKey: 'rain',
    severity: 'moderate',
    affectedCustomers: 430,
    reportedAt: iso(520),
    wentOutAt: iso(524),
    estimatedRestoration: iso(300),
    confidence: 98,
    section: 'Kumily Electrical Section',
    engineer: 'Er. Deepa Menon',
    crewNumber: 'CREW-02',
    vehicle: 'KL-06-AA-3345',
    contact: '+91 486 222 0166',
    crewStatus: 'completed',
  },
  {
    id: 'PP-2016',
    area: 'Vagamon',
    district: 'Idukki',
    lat: 9.6864,
    lng: 76.9036,
    status: 'outage',
    cause: 'Flooded Substation',
    causeKey: 'flood',
    severity: 'critical',
    affectedCustomers: 990,
    reportedAt: iso(12),
    wentOutAt: iso(16),
    estimatedRestoration: isoAhead(240),
    confidence: 70,
    section: 'Vagamon Electrical Section',
    engineer: 'Er. Rahul Dev',
    crewNumber: 'CREW-08',
    vehicle: 'KL-06-AF-5567',
    contact: '+91 486 244 0122',
    crewStatus: 'assigned',
  },
  {
    id: 'PP-2012',
    area: 'Thodupuzha',
    district: 'Idukki',
    lat: 9.895,
    lng: 76.7167,
    status: 'restoring',
    cause: 'Scheduled Line Maintenance',
    causeKey: 'maintenance',
    severity: 'low',
    affectedCustomers: 310,
    reportedAt: iso(80),
    wentOutAt: iso(84),
    estimatedRestoration: isoAhead(40),
    confidence: 99,
    section: 'Thodupuzha Electrical Section',
    engineer: 'Er. Nikhil Raj',
    crewNumber: 'CREW-01',
    vehicle: 'KL-06-AA-1001',
    contact: '+91 486 222 0100',
    crewStatus: 'repairing',
  },
]

export const primaryOutage = outages[0]

export interface TimelineStage {
  key: string
  label: string
  time: string | null
  done: boolean
  active?: boolean
}

export const outageTimeline: TimelineStage[] = [
  { key: 'out', label: 'Power Out', time: '2:12 PM', done: true },
  { key: 'complaint', label: 'Complaint Registered', time: '2:16 PM', done: true },
  { key: 'assigned', label: 'Crew Assigned', time: '2:29 PM', done: true },
  { key: 'reached', label: 'Crew Reached', time: '3:04 PM', done: true },
  {
    key: 'repair',
    label: 'Repair Started',
    time: '3:18 PM',
    done: true,
    active: true,
  },
  { key: 'testing', label: 'Testing', time: null, done: false },
  { key: 'restored', label: 'Power Restored', time: null, done: false },
]

export interface StatCard {
  label: string
  value: number
  suffix?: string
  prefix?: string
  trend: string
  trendUp: boolean
  tone: 'info' | 'power-on' | 'power-off' | 'warning'
}

export const dashboardStats: StatCard[] = [
  {
    label: 'Active Outages',
    value: 3,
    trend: '+1 last hour',
    trendUp: false,
    tone: 'power-off',
  },
  {
    label: 'Repair Crews Active',
    value: 11,
    trend: '4 en route',
    trendUp: true,
    tone: 'info',
  },
  {
    label: 'Power Restored Today',
    value: 47,
    trend: '+12 today',
    trendUp: true,
    tone: 'power-on',
  },
  {
    label: 'Citizen Reports',
    value: 128,
    trend: '+23 today',
    trendUp: true,
    tone: 'warning',
  },
]

export const landingStats: StatCard[] = [
  {
    label: 'Outages Today',
    value: 12,
    trend: 'High range',
    trendUp: false,
    tone: 'power-off',
  },
  {
    label: 'Active Repair Crews',
    value: 11,
    trend: 'Deployed',
    trendUp: true,
    tone: 'info',
  },
  {
    label: 'Power Restored',
    value: 47,
    suffix: '',
    trend: 'Today',
    trendUp: true,
    tone: 'power-on',
  },
  {
    label: 'Citizen Reports',
    value: 128,
    trend: 'Verified',
    trendUp: true,
    tone: 'warning',
  },
]

export type ResourceType =
  | 'charging'
  | 'hospital'
  | 'pharmacy'
  | 'generator'
  | 'food'
  | 'water'
  | 'atm'
  | 'relief'
  | 'police'
  | 'fire'

export interface Resource {
  id: string
  name: string
  type: ResourceType
  distanceKm: number
  open: boolean
  hasPower: boolean
  area: string
  lat: number
  lng: number
}

export const resources: Resource[] = [
  {
    id: 'r1',
    name: 'Munnar Community Charging Hub',
    type: 'charging',
    distanceKm: 0.8,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0895,
    lng: 77.0605,
  },
  {
    id: 'r2',
    name: 'Tata General Hospital',
    type: 'hospital',
    distanceKm: 1.4,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0912,
    lng: 77.058,
  },
  {
    id: 'r3',
    name: 'HillTop Pharmacy',
    type: 'pharmacy',
    distanceKm: 0.6,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.087,
    lng: 77.061,
  },
  {
    id: 'r4',
    name: 'KSEB Generator Point',
    type: 'generator',
    distanceKm: 2.1,
    open: true,
    hasPower: true,
    area: 'Adimali',
    lat: 10.0135,
    lng: 76.9571,
  },
  {
    id: 'r5',
    name: 'Annapoorna Relief Kitchen',
    type: 'food',
    distanceKm: 1.1,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0865,
    lng: 77.057,
  },
  {
    id: 'r6',
    name: 'Municipal Water Tanker Point',
    type: 'water',
    distanceKm: 1.9,
    open: false,
    hasPower: false,
    area: 'Munnar',
    lat: 10.0851,
    lng: 77.062,
  },
  {
    id: 'r7',
    name: 'Federal Bank ATM (Solar)',
    type: 'atm',
    distanceKm: 0.9,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0881,
    lng: 77.0588,
  },
  {
    id: 'r8',
    name: 'Govt. HSS Relief Camp',
    type: 'relief',
    distanceKm: 3.2,
    open: true,
    hasPower: true,
    area: 'Adimali',
    lat: 10.011,
    lng: 76.9545,
  },
  {
    id: 'r9',
    name: 'Munnar Police Station',
    type: 'police',
    distanceKm: 1.0,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0902,
    lng: 77.0598,
  },
  {
    id: 'r10',
    name: 'Fire & Rescue Station',
    type: 'fire',
    distanceKm: 2.6,
    open: true,
    hasPower: true,
    area: 'Munnar',
    lat: 10.0925,
    lng: 77.055,
  },
]

export type ReportType =
  | 'power-out'
  | 'power-restored'
  | 'broken-pole'
  | 'transformer-blast'
  | 'tree-fallen'
  | 'wire-spark'
  | 'road-block'
  | 'flood'

export interface CommunityReport {
  id: string
  type: ReportType
  label: string
  area: string
  note: string
  timeAgo: string
  status: 'verified' | 'reviewing' | 'new'
  reporter: string
}

export const reportTypes: { key: ReportType; label: string }[] = [
  { key: 'power-out', label: 'Power Out' },
  { key: 'power-restored', label: 'Power Restored' },
  { key: 'broken-pole', label: 'Broken Pole' },
  { key: 'transformer-blast', label: 'Transformer Blast' },
  { key: 'tree-fallen', label: 'Tree Fallen' },
  { key: 'wire-spark', label: 'Wire Spark' },
  { key: 'road-block', label: 'Road Block' },
  { key: 'flood', label: 'Flood' },
]

export const communityReports: CommunityReport[] = [
  {
    id: 'c1',
    type: 'tree-fallen',
    label: 'Tree Fallen',
    area: 'Munnar, Old Bazaar Rd',
    note: 'Large tree down across the 11kV line near the tea museum.',
    timeAgo: '8 min ago',
    status: 'verified',
    reporter: 'Arun P.',
  },
  {
    id: 'c2',
    type: 'wire-spark',
    label: 'Wire Spark',
    area: 'Adimali, NH-85',
    note: 'Sparking from a low-hanging wire near the bus stand.',
    timeAgo: '21 min ago',
    status: 'reviewing',
    reporter: 'Sneha K.',
  },
  {
    id: 'c3',
    type: 'flood',
    label: 'Flood',
    area: 'Vagamon, Kolahalamedu',
    note: 'Substation approach road waterlogged, crew access blocked.',
    timeAgo: '34 min ago',
    status: 'verified',
    reporter: 'Jose M.',
  },
  {
    id: 'c4',
    type: 'power-restored',
    label: 'Power Restored',
    area: 'Kattappana, Town',
    note: 'Supply back in our ward after the lightning trip. Thanks crew!',
    timeAgo: '52 min ago',
    status: 'verified',
    reporter: 'Reena T.',
  },
  {
    id: 'c5',
    type: 'road-block',
    label: 'Road Block',
    area: 'Nedumkandam, Hillside',
    note: 'Landslide debris on road, JCB needed for crew vehicle.',
    timeAgo: '1 hr ago',
    status: 'new',
    reporter: 'Anonymous',
  },
]

export interface NotificationItem {
  id: string
  type: 'outage' | 'crew' | 'repair' | 'weather' | 'warning' | 'restored'
  title: string
  message: string
  time: string
  read: boolean
}

export const notifications: NotificationItem[] = [
  {
    id: 'n1',
    type: 'outage',
    title: 'Power Out — Vagamon',
    message: 'Flooded substation isolated for safety. 990 customers affected.',
    time: '12 min ago',
    read: false,
  },
  {
    id: 'n2',
    type: 'crew',
    title: 'Crew Assigned — Nedumkandam',
    message: 'CREW-05 dispatched to the landslide-affected feeder corridor.',
    time: '26 min ago',
    read: false,
  },
  {
    id: 'n3',
    type: 'repair',
    title: 'Repair Started — Munnar Town',
    message: 'Tree removal underway on the 11kV feeder. ETA 2h 15m.',
    time: '48 min ago',
    read: true,
  },
  {
    id: 'n4',
    type: 'weather',
    title: 'Heavy Rain Alert — Idukki',
    message: 'IMD orange alert. Expect intermittent preventive shutdowns.',
    time: '1 hr ago',
    read: true,
  },
  {
    id: 'n5',
    type: 'warning',
    title: 'Landslide Warning — Nedumkandam',
    message: 'District administration advises against hillside travel.',
    time: '2 hr ago',
    read: true,
  },
  {
    id: 'n6',
    type: 'restored',
    title: 'Power Restored — Kattappana',
    message: 'Supply restored to 860 customers after lightning repair.',
    time: '2 hr ago',
    read: true,
  },
]

// Analytics data
export const monthlyOutages = [
  { month: 'Jan', outages: 34, restored: 33 },
  { month: 'Feb', outages: 28, restored: 28 },
  { month: 'Mar', outages: 41, restored: 40 },
  { month: 'Apr', outages: 52, restored: 50 },
  { month: 'May', outages: 88, restored: 84 },
  { month: 'Jun', outages: 164, restored: 151 },
  { month: 'Jul', outages: 198, restored: 182 },
  { month: 'Aug', outages: 142, restored: 137 },
]

export const causeBreakdown = [
  { name: 'Tree Fall', value: 32, fill: 'var(--color-chart-2)' },
  { name: 'Heavy Rain', value: 24, fill: 'var(--color-chart-1)' },
  { name: 'Transformer', value: 18, fill: 'var(--color-chart-4)' },
  { name: 'Lightning', value: 14, fill: 'var(--color-chart-3)' },
  { name: 'Landslide', value: 12, fill: 'var(--color-chart-5)' },
]

export const avgRepairTime = [
  { area: 'Munnar', hours: 2.4 },
  { area: 'Adimali', hours: 3.1 },
  { area: 'Kattappana', hours: 1.8 },
  { area: 'Nedumkandam', hours: 4.2 },
  { area: 'Peerumedu', hours: 2.0 },
  { area: 'Vagamon', hours: 3.6 },
]

export const restorationTrend = [
  { day: 'Mon', rate: 94 },
  { day: 'Tue', rate: 91 },
  { day: 'Wed', rate: 88 },
  { day: 'Thu', rate: 96 },
  { day: 'Fri', rate: 92 },
  { day: 'Sat', rate: 97 },
  { day: 'Sun', rate: 95 },
]

export const areaRanking = [
  { area: 'Nedumkandam', outages: 41, avgHours: 4.2, trend: 'up' },
  { area: 'Vagamon', outages: 36, avgHours: 3.6, trend: 'up' },
  { area: 'Adimali', outages: 29, avgHours: 3.1, trend: 'down' },
  { area: 'Munnar', outages: 24, avgHours: 2.4, trend: 'down' },
  { area: 'Peerumedu', outages: 19, avgHours: 2.0, trend: 'down' },
]

export const chatSuggestions = [
  'Why is power gone?',
  'When will it return?',
  'Nearest charging station?',
  'Nearest hospital?',
  'Current power status?',
]
