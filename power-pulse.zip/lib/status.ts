import type { OutageStatus, CrewStatus } from './data'

export const outageStatusMeta: Record<
  OutageStatus,
  { label: string; text: string; bg: string; dot: string }
> = {
  outage: {
    label: 'Power Outage',
    text: 'text-power-off',
    bg: 'bg-power-off/12 border-power-off/30',
    dot: 'bg-power-off',
  },
  restoring: {
    label: 'Restoring',
    text: 'text-warning',
    bg: 'bg-warning/12 border-warning/30',
    dot: 'bg-warning',
  },
  restored: {
    label: 'Power Available',
    text: 'text-power-on',
    bg: 'bg-power-on/12 border-power-on/30',
    dot: 'bg-power-on',
  },
}

export const crewStatusMeta: Record<CrewStatus, { label: string; tone: string }> =
  {
    assigned: { label: 'Assigned', tone: 'text-info bg-info/12 border-info/30' },
    travelling: {
      label: 'Travelling',
      tone: 'text-warning bg-warning/12 border-warning/30',
    },
    repairing: {
      label: 'Repairing',
      tone: 'text-warning bg-warning/12 border-warning/30',
    },
    testing: { label: 'Testing', tone: 'text-info bg-info/12 border-info/30' },
    completed: {
      label: 'Completed',
      tone: 'text-power-on bg-power-on/12 border-power-on/30',
    },
  }

export const severityMeta: Record<string, { label: string; tone: string }> = {
  low: { label: 'Low', tone: 'text-power-on bg-power-on/12 border-power-on/30' },
  moderate: {
    label: 'Moderate',
    tone: 'text-warning bg-warning/12 border-warning/30',
  },
  high: { label: 'High', tone: 'text-warning bg-warning/12 border-warning/30' },
  critical: {
    label: 'Critical',
    tone: 'text-power-off bg-power-off/12 border-power-off/30',
  },
}

export function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('en-IN', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  })
}

export function timeUntil(iso: string) {
  const diff = new Date(iso).getTime() - Date.now()
  if (diff <= 0) return 'Now'
  const mins = Math.round(diff / 60000)
  const h = Math.floor(mins / 60)
  const m = mins % 60
  if (h === 0) return `${m} min`
  return `${h}h ${m}m`
}

export function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.max(0, Math.round(diff / 60000))
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins} min ago`
  const h = Math.floor(mins / 60)
  const m = mins % 60
  if (h < 24) return m === 0 ? `${h}h ago` : `${h}h ${m}m ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

export function durationSince(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.max(0, Math.round(diff / 60000))
  const h = Math.floor(mins / 60)
  const m = mins % 60
  if (h === 0) return `${m}m`
  return `${h}h ${m}m`
}
